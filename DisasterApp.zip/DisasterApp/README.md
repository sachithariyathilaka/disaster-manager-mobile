# android-wifi-direct-chat-app
a simple android application using Android device wifi-direct (p2p)

#Download link:
[Download APK](https://drive.google.com/open?id=1eWoMSBKaXUrIe15fLQllMUC3WNClNAji)

#test link:
[test](https://drive.google.com/drive/folders/1pchhSSxqVF6453fOGT7kFPLD5ZC2tN0d?usp=sharing)

#TODO:
1. reskin app
